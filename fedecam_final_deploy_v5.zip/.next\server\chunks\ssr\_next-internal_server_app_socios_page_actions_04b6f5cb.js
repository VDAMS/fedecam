module.exports=[64618,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_socios_page_actions_04b6f5cb.js.map