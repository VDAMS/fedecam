module.exports=[43147,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_quienes-somos_page_actions_472c7139.js.map