module.exports=[7060,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_noticias_page_actions_da20ccd1.js.map