module.exports=[16486,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mision-vision_page_actions_815e8e8b.js.map