module.exports=[5577,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_noticias_leer_page_actions_26904351.js.map